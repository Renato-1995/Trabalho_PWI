Elite Grand Hotel
