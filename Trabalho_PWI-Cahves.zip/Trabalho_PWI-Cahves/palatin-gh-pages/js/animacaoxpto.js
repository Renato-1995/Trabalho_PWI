$(document).ready(function() {
    var $leftColumn = $('.left-column');
    var $rightColumn = $('.right-column');

    $(window).scroll(function() {
        var scrollTop = $(this).scrollTop();
        $leftColumn.css('transform', 'translateY(' + scrollTop + 'px)');
        $rightColumn.css('transform', 'translateY(-' + scrollTop + 'px)');
    });
});
